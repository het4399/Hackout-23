const sendEmail = require('./nodemailer');

// Call the sendEmail function to send an email
sendEmail();
